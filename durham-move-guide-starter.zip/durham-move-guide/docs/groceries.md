# Groceries & Indian Stores (Durham)

## Big-box & general
- Costco, Sam’s Club, Walmart, Target, Harris Teeter, Publix, Food Lion

## Indian & Asian groceries (starter list)
- Patel Brothers (Morrisville)
- Apna Bazaar
- H Mart (Cary)
- Grand Asia Market

## Tips
- Compare prices across stores for staples (rice, atta, spices).
- Many shops run **weekly specials** — check flyers or apps.
- Consider a **Costco membership** if you buy in bulk.
