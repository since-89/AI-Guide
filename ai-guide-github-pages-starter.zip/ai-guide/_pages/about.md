---
title: "About"
permalink: /about/
---

**AI Guide** — *America–India Living, Made Easy.*  
I write practical, experience-based guides to help Indians settle in the USA smoothly.
