---
title: "Guides"
permalink: /guides/
---

A growing collection of step-by-step guides for Indians moving to (and settling in) the USA.

- **EAD Application Guide (Form I-765)** — online filing, documents, timelines, renewal tips.
